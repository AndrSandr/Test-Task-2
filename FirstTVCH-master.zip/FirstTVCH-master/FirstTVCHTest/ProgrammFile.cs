﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstTVCHTest
{
    class ProgrammFile
    {
        public long tvFilesId { get; set; }
        public long totvId { get; set; } 
        public string FileName { get; set; }
        public long  FrameCount { get; set; }
        public string FilePath { get; set; }
        public string FrameFormat { get; set; }
        public string FrameSize { get; set; }
        public bool isDelete { get; set; } = false;

    }
}
