﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstTVCHTest
{
    class TvProgram
    {
        public int tvId { get; set; }
        public string ProgrammName { get; set; }
        public string Description { get; set; }
        public string ActorNames { get; set; }
        public int YearOfCreate { get; set; }

    }
}
