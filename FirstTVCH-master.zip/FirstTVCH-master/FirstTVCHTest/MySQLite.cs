﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.IO;
using System.Windows;

namespace FirstTVCHTest
{
    class MySQLite
    {

        public string databaseName;
        public MySQLite()
        {
            databaseName = @"FirstTVCH.db";
        }


        public SQLiteConnection GetConnection()
        {
            return new SQLiteConnection(string.Format("Data Source={0};", databaseName));
        }

        //проверка наличия базы данных. Создание БД и таблиц, если файл БД не найден.
        public void CheckDB()
        {

            if (!File.Exists(databaseName))
            {
                SQLiteConnection.CreateFile(databaseName);
                SQLiteConnection conn = new SQLiteConnection(string.Format("Data Source={0};", databaseName));
                conn.Open();
                SQLiteCommand cmd = conn.CreateCommand();
                string sql_comm = "DROP TABLE IF EXISTS TvProgramm;" +
                    "CREATE TABLE TvProgramm(" +
                    "tvId  INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "ProgrammName NVARCHAR(256) not NULL," +
                    "Description NVARCHAR(2048) NULL," +
                    "ActorNames NVARCHAR(512) NULL," +
                    "YearOfCreate INTEGER NULL);" +

                    "DROP TABLE IF EXISTS TvProgrammFiles;" +
                    "CREATE TABLE TvProgrammFiles(" +
                    "tvFilesId INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "totvId int not NULL," + 
                    "FileName NVARCHAR(256) not NULL," +
                    "FrameCount int not NULL," +
                    "FilePath NVARCHAR(256) not NULL," +
                    "FrameFormat NVARCHAR(8) not NULL," +
                    "FrameSize NVARCHAR(16) not NULL);" ;
                cmd.CommandText = sql_comm;
                try
                {
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                catch (SQLiteException ex)
                {
                    System.Windows.MessageBox.Show(ex.Message, "Ошибка!");
                    conn.Close();
                }
            }
        }

    }
}
