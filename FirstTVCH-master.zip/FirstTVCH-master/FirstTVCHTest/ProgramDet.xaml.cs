﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SQLite;
using System.IO;
using MediaInfoDotNet;

namespace FirstTVCHTest
{
    /// <summary>
    /// Логика взаимодействия для ProgramDet.xaml
    /// </summary>
    public partial class ProgramDet : Window
    {
        public long  tvId=0;
        public ProgramDet()
        {
            InitializeComponent();
        }

        private void FormDet_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tvId > 0)
                {

                    MySQLite sqlObj = new MySQLite();
                    sqlObj.CheckDB();
                    var sqlConnection = sqlObj.GetConnection();
                    sqlConnection.Open();
                    var sqlCommand = new SQLiteCommand("select * from TvProgramm where tvId=" + tvId.ToString(), sqlConnection);
                    SQLiteDataReader rdMain = sqlCommand.ExecuteReader();
                    if (rdMain.Read())
                    {
                        editName.Text = rdMain["ProgrammName"].ToString();
                        editDescript.Text = rdMain["Description"].ToString();
                        editActors.Text = rdMain["ActorNames"].ToString();
                        editYear.Text = rdMain["YearOfCreate"].ToString();

                        var sqlCommandFile = new SQLiteCommand("select *  from TvProgrammFiles where totvId=" + tvId.ToString(), sqlConnection);
                        SQLiteDataReader rdFile = sqlCommandFile.ExecuteReader();
                        while (rdFile.Read())
                        {
                            var prFile = new ProgrammFile();
                            prFile.tvFilesId = (long)rdFile["tvFilesId"];
                            prFile.totvId = Convert.ToInt64(rdFile["totvId"].ToString());
                            prFile.FileName = rdFile["FileName"].ToString();
                            prFile.FilePath = rdFile["FilePath"].ToString();
                            prFile.FrameCount = Convert.ToInt64(rdFile["FrameCount"].ToString());
                            prFile.FrameFormat = rdFile["FrameFormat"].ToString();
                            prFile.FrameSize = rdFile["FrameSize"].ToString();
                            dgFiles.Items.Add(prFile);
                        }
                        rdFile.Close();
                    }
                    rdMain.Close();
                    sqlConnection.Close();
                }
            }
            catch (SQLiteException ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Ошибка в FormDet_Loaded!");
            }

        }

        private void MarkRowAsDelete(object sender, RoutedEventArgs e)
        {
            ProgrammFile prFile = (ProgrammFile)dgFiles.SelectedItem;
            if (prFile!=null)
            {
                prFile.isDelete = true;
                dgFiles.Items.Filter = new Predicate<object>(item => ((ProgrammFile)item).isDelete == false);
            }
        }

        private void btn_ok_Click(object sender, RoutedEventArgs e)
        {
            MySQLite sqlObj = new MySQLite();
            var sqlConnection = sqlObj.GetConnection();
            sqlConnection.Open();
            if (tvId<=0)
            {
                
                string sql_cmd = string.Format("Insert into TvProgramm (ProgrammName , Description , ActorNames , YearOfCreate) values ('{0}','{1}','{2}',{3});SELECT last_insert_rowid();", editName.Text, editDescript.Text, editActors.Text, Convert.ToInt32(editYear.Text));
                var sqlCommand = new SQLiteCommand(sql_cmd, sqlConnection);
                object tvId_new = sqlCommand.ExecuteScalar();
                tvId = (long)tvId_new;
            }
            else
            {
                string sql_cmd = string.Format("Update TvProgramm SET ProgrammName='{0}' , Description ='{1}'  , ActorNames = '{2}' , YearOfCreate = {3} where tvId= {4};", editName.Text, editDescript.Text, editActors.Text, Convert.ToInt32(editYear.Text), tvId);
                var sqlCommand = new SQLiteCommand(sql_cmd, sqlConnection);
                sqlCommand.ExecuteNonQuery();
            }
            sqlConnection.Close();
            Save_ProgramFiles();
            this.Close();
        }

        //сохрание передачи в базе. Добавляем новые файлы, удаляем помеченные на удаление.
        private void Save_ProgramFiles()
        {
            if (tvId == 0)
                return;
            MySQLite sqlObj = new MySQLite();
            var sqlConnection = sqlObj.GetConnection();
            dgFiles.Items.Filter = null;
            foreach (ProgrammFile prFile in dgFiles.Items)
            {
                string sql_cmd="";

                prFile.totvId = tvId;

                if (prFile.tvFilesId == 0)
                    sql_cmd = string.Format("Insert into TvProgrammFiles (totvId , FileName ,FrameCount , FilePath , FrameFormat , FrameSize) values ({0},'{1}',{2},'{3}','{4}','{5}');",
                            prFile.totvId, prFile.FileName, prFile.FrameCount, prFile.FilePath, prFile.FrameFormat, prFile.FrameSize);
                if (prFile.tvFilesId > 0 && prFile.isDelete)
                    sql_cmd = string.Format("Delete from TvProgrammFiles where tvFilesId = {0}", prFile.tvFilesId);
                if (sql_cmd!="")
                {
                    if (sqlConnection.State != ConnectionState.Open)
                        sqlConnection.Open();
                    var sqlCommand = new SQLiteCommand(sql_cmd, sqlConnection);
                    sqlCommand.ExecuteNonQuery();
                }

            }
            if (sqlConnection.State == ConnectionState.Open)
                sqlConnection.Close();
        }

        private void btn_cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void dgFiles_Drop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string file in files)
            {
                var prFile = new ProgrammFile();

                MediaFile mf = new MediaFile(file);
                if (mf.Video.Count == 0)
                {
                    System.Windows.MessageBox.Show("Данный формат файла не поддерживается!", "Ошибка!");
                    return;
                }

                prFile.FilePath = file;
                prFile.FileName = System.IO.Path.GetFileName(file);
                prFile.FrameCount = mf.Video[0].FrameCount;
                prFile.FrameFormat = mf.Video[0].Format;
                prFile.FrameSize = mf.Video[0].Width.ToString() + "x" + mf.Video[0].Height.ToString();

                dgFiles.ItemsSource = null;
                dgFiles.Items.Add(prFile);
                
            }
        }

     
    }
}
