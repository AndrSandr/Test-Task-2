﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Data;
using System.Data.SQLite;

namespace FirstTVCHTest
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ProgramDet formDet;
        public MainWindow()
        {
            InitializeComponent();
            Load_Data();
        }
        //загрузка списка передач
        public void Load_Data()
        {
            MySQLite sqlObj = new MySQLite();
            sqlObj.CheckDB();
            var sqlConnection = sqlObj.GetConnection();
            sqlConnection.Open();

            var sqlCommand = new SQLiteCommand("select tvId,ProgrammName from TvProgramm", sqlConnection);
            sqlCommand.ExecuteNonQuery();

            var dataTable = new DataTable("List");
            var sqlAdapter = new SQLiteDataAdapter(sqlCommand);
            sqlAdapter.Fill(dataTable);
            programmGrid.ItemsSource = dataTable.DefaultView;
            
            sqlAdapter.Update(dataTable);
            sqlConnection.Close();
        }

        private void programmGrid_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName.StartsWith("tvId"))
                e.Column.Header = "ID";
            if (e.PropertyName.StartsWith("ProgrammName"))
                e.Column.Header = "Название передачи";
        }

        private void ShowProgramDet(long tvId)
        {
            formDet = new ProgramDet();
            formDet.tvId = tvId;
            formDet.ShowDialog();
            Load_Data();
        }

        private long GetCurrentTvId()
        {
            int curRow = programmGrid.SelectedIndex;
            long tvId = 0;
            if (curRow >= 0)
            {
                DataRowView row = programmGrid.SelectedItem as DataRowView;
                tvId = Convert.ToInt64(row.Row["tvId"].ToString());
            }
            return tvId;
        }

        private void programmGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ShowProgramDet(GetCurrentTvId());
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ShowProgramDet(0);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MySQLite sqlObj = new MySQLite();
            var sqlConnection = sqlObj.GetConnection();
            sqlConnection.Open();
            long tvId = GetCurrentTvId();
            var sqlCommand = new SQLiteCommand("Delete from TvProgramm where tvId= " + tvId.ToString(), sqlConnection);
            sqlCommand.ExecuteNonQuery();
            Load_Data();
        }
    }
}
